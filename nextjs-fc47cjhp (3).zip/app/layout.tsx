import './globals.css';
// We must import React to use the React.ReactNode type
import React from 'react';
// FIX: Changed absolute path @/ to explicit relative path ./
import { GameProvider } from './context/GameContext';

export const metadata = {
  title: 'The Infinite Scholar',
  description: 'An Educational RPG',
};

// Applying explicit type annotation to the children prop
export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="bg-cyber-black text-cyber-text font-mono h-screen w-screen overflow-hidden selection:bg-cyber-neonGreen selection:text-black">
        <GameProvider>{children}</GameProvider>
      </body>
    </html>
  );
}
